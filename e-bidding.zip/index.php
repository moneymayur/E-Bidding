<?php

header ('Location: index1.php?start=0&session=0');
	?>